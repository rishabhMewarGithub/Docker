angular.module("klondike", [
  "klondike.game",
  "klondike.board",
  "klondike.scoring"
]);
